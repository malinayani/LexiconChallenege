import React from 'react'

    const Contacts = ({ cinemaWorld }) => {
      return (
        <div>
          <center><h1 style={{ fontSize: 45, color: 'grey' }}>CinemaWorld Movies</h1></center>
          {cinemaWorld.map((movie) => (
            <div class="card">
              <div class="card-body">
                <img src={movie.Poster}></img>
                <h5 class="card-title" >{movie.Title }</h5>
                <h6 class="card-subtitle mb-2 text-muted" >{movie.Title}</h6>
                <p class="card-text" >{movie.Type}</p>
                <tr>
                  <td><a href={"www.google.com"}>Click here to go to home page</a></td>
              </tr>
              </div>
            </div>
          ))}
        </div>
      )
    };

    export default Contacts